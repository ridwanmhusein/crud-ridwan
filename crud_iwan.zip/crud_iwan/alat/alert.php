<div class="bg-slate-100">
      <?php if(isset($_COOKIE['message'])) : ?>
        <div class="p-3 bg-red-500 m-3 rounded-xl text-white">
          <?= $_COOKIE['message'] ?>
        </div>
      <?php endif ?>
    </div>