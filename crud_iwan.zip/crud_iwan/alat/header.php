<nav class=" bg-black text-white">
        <div class="py-3 px-5">
            <div class="flex items-center">
                <h1 class="font-bold text-3xl mr-auto">Kelas XI-RPL</h1>
                <ul class="flex flex-row font-medium space-x-7 mr-6 text-xm text-sm">
                    <li class="hover:underline"><a href="#">Home</a></li>
                    <li class="hover:underline"><a href="#">Absent</a></li>
                    <li class="hover:underline"><a href="#">History</a></li>
                    <li class="hover:underline"><a href="#">About</a></li>
                </ul>
            </div>
        </div>
    </nav>